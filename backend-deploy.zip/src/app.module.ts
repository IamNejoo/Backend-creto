// app.module.ts

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config'; // <-- 1. IMPORTA EL MÓDULO
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { PrismaModule } from './prisma/prisma.module';
import { ProductModule } from './product/product.module';
import { VariantModule } from './variant/variant.module';
import { InventoryModule } from './inventory/inventory.module';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { UsersModule } from './users/users.module';
import { RaffleModule } from './raffle/raffle.module';
import { ScheduleModule } from '@nestjs/schedule';
import { PaymentsModule } from './payments/payments.module';
import { OrdersModule } from './orders/orders.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { AccountModule } from './account/account.module';
@Module({
  imports: [
    // 2. AGRÉGALO AQUÍ, idealmente al principio
    ConfigModule.forRoot({
      isGlobal: true, // <-- Esto es MUY importante
    }),
    ThrottlerModule.forRoot([
      {
        name: 'short',
        ttl: 1000,
        limit: 3,
      },
      {
        name: 'medium',
        ttl: 10000,
        limit: 20,
      },
      {
        name: 'long',
        ttl: 60000,
        limit: 100,
      },
    ]),
    PrismaModule,
    AuthModule,
    ProductModule,
    VariantModule,
    InventoryModule,
    UsersModule,
    RaffleModule,
    ScheduleModule.forRoot(),
    PaymentsModule,
    OrdersModule,
    DashboardModule,
    AccountModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule { }