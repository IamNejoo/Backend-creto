// src/common/middleware/mp-webhook-signature.middleware.ts
import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import type { Request, Response, NextFunction } from 'express';

/**
 * Verificación simple de firma para el webhook de Mercado Pago.
 *
 * Si MP_WEBHOOK_SECRET está definido:
 *   - acepta header:   x-mp-signature: <secreto>
 *   - o query string:  ?secret=<secreto>
 * Si NO está definido, permite el paso (útil en desarrollo/sandbox).
 *
 * Nota: MP tiene un esquema de firma más elaborado dependiendo del entorno.
 * Esto deja el hook listo para endurecerlo cuando lo requieras.
 */
@Injectable()
export class MpWebhookSignatureMiddleware implements NestMiddleware {
    use(req: Request, _res: Response, next: NextFunction) {
        const required = process.env.MP_WEBHOOK_SECRET;
        if (!required) {
            return next(); // sin secreto configurado → permitir (dev/sandbox)
        }

        const header = req.headers['x-mp-signature'] as string | undefined;
        const q = (req.query?.secret as string | undefined) ?? undefined;

        const provided = (header || q || '').trim();
        if (!provided || provided !== required) {
            throw new UnauthorizedException('Invalid webhook signature');
        }

        return next();
    }
}
