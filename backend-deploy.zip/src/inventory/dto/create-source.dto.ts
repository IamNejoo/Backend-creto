import { IsBoolean, IsEnum, IsOptional, IsString } from 'class-validator';
import { InventorySourceType } from '../../../generated/prisma';


export class CreateSourceDto {
    @IsString() name: string;
    @IsEnum(InventorySourceType) type: InventorySourceType; // 'supplier' | 'warehouse'
    @IsOptional() @IsBoolean() active?: boolean = true;
}
