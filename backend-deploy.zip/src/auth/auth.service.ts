// src/auth/auth.service.ts
import {
    Injectable,
    ConflictException,
    UnauthorizedException,
    NotFoundException,
    BadRequestException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import * as argon2 from 'argon2';
import * as crypto from 'crypto';

@Injectable()
export class AuthService {
    constructor(
        private prisma: PrismaService,
        private jwt: JwtService,
    ) { }

    /* ------------------------------------------------------------------
     * REGISTER
     * ------------------------------------------------------------------ */
    async register(dto: RegisterDto) {
        const { email, password, phone, name, lastname, avatarUrl } = dto as any;

        const existing = await this.prisma.user.findUnique({ where: { email } });
        if (existing) throw new ConflictException('El usuario ya existe');

        const hash = await argon2.hash(password);

        const user = await this.prisma.user.create({
            data: { email, hash, phone, name, lastname, avatarUrl },
            select: {
                id: true,
                email: true,
                phone: true,
                role: true,
                createdAt: true,
                name: true,
                lastname: true,
                avatarUrl: true,
            },
        });

        const access_token = await this.signToken(user.id, user.email);
        return { message: 'Usuario registrado exitosamente', user, access_token };
    }

    /* ------------------------------------------------------------------
     * LOGIN
     * ------------------------------------------------------------------ */
    async login(loginDto: LoginDto) {
        const { email, password } = loginDto;

        const user = await this.prisma.user.findUnique({
            where: { email },
        });
        if (!user) throw new UnauthorizedException('Credenciales inválidas');

        const valid = await argon2.verify(user.hash, password);
        if (!valid) throw new UnauthorizedException('Credenciales inválidas');

        const token = await this.signToken(user.id, user.email);
        return {
            message: 'Login exitoso',
            user: {
                id: user.id,
                email: user.email,
                phone: user.phone,
                role: user.role,
                name: (user as any).name ?? null,
                lastname: (user as any).lastname ?? null,
                avatarUrl: (user as any).avatarUrl ?? null,
                createdAt: user.createdAt,
            },
            access_token: token,
        };
    }

    /* ------------------------------------------------------------------
     * PROFILE VALIDATION (JWT strategy)
     * ------------------------------------------------------------------ */
    async validateUser(userId: string) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: {
                id: true,
                email: true,
                phone: true,
                role: true,
                createdAt: true,
                name: true,
                lastname: true,
                avatarUrl: true,
            },
        });
        return user;
    }

    /* ------------------------------------------------------------------
     * PASSWORD: CHANGE (autenticado)
     * ------------------------------------------------------------------ */
    async changePassword(userId: string, oldPassword: string, newPassword: string) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user) throw new NotFoundException('Usuario no encontrado');

        const ok = await argon2.verify(user.hash, oldPassword);
        if (!ok) throw new UnauthorizedException('Contraseña actual incorrecta');

        const newHash = await argon2.hash(newPassword);
        await this.prisma.user.update({
            where: { id: userId },
            data: { hash: newHash },
        });

        // Opcional: invalidar tokens de reseteo previos
        await this.prisma.passwordResetToken.updateMany({
            where: { userId, usedAt: null, expiresAt: { gt: new Date() } },
            data: { usedAt: new Date() },
        });

        return { message: 'Contraseña actualizada exitosamente' };
    }

    /* ------------------------------------------------------------------
     * PASSWORD: REQUEST RESET (público)
     * Crea un token de un solo uso, válido por 60 minutos
     * ------------------------------------------------------------------ */
    async requestPasswordReset(email: string) {
        // No revelar si el email existe o no
        const user = await this.prisma.user.findUnique({ where: { email } });
        if (!user) {
            return {
                message:
                    'Si el correo existe, recibirás un enlace para restablecer tu contraseña.',
            };
        }

        // Generar token aleatorio y su hash determinístico (sha256) para guardar
        const rawToken = crypto.randomBytes(32).toString('hex');
        const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 60 min

        // Opcional: invalidar tokens anteriores vigentes
        await this.prisma.passwordResetToken.updateMany({
            where: { userId: user.id, usedAt: null, expiresAt: { gt: new Date() } },
            data: { usedAt: new Date() },
        });

        await this.prisma.passwordResetToken.create({
            data: {
                userId: user.id,
                tokenHash,
                expiresAt,
            },
        });

        // TODO: Integrar servicio de email.
        // Por ahora, retornamos el token para facilidad de pruebas manuales en dev.
        // En producción, NO retornes el token; envíalo por correo.
        // Ejemplo de enlace: `${FRONTEND_URL}/reset-password?token=${rawToken}`
        return {
            message:
                'Si el correo existe, recibirás un enlace para restablecer tu contraseña.',
            // ⚠️ Solo para desarrollo:
            devToken: rawToken,
        };
    }

    /* ------------------------------------------------------------------
     * PASSWORD: RESET (público)
     * Recibe el token del correo + nueva contraseña
     * ------------------------------------------------------------------ */
    async resetPassword(rawToken: string, newPassword: string) {
        if (!rawToken || !newPassword) {
            throw new BadRequestException('Datos incompletos');
        }

        const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
        const record = await this.prisma.passwordResetToken.findFirst({
            where: {
                tokenHash,
                usedAt: null,
                expiresAt: { gt: new Date() },
            },
            include: { user: true },
        });

        if (!record || !record.user) {
            throw new UnauthorizedException('Token inválido o expirado');
        }

        const newHash = await argon2.hash(newPassword);

        // Transacción: actualizar contraseña + marcar token usado
        await this.prisma.$transaction([
            this.prisma.user.update({
                where: { id: record.userId },
                data: { hash: newHash },
            }),
            this.prisma.passwordResetToken.update({
                where: { id: record.id },
                data: { usedAt: new Date() },
            }),
            // Opcional: invalidar otros tokens vigentes del mismo usuario
            this.prisma.passwordResetToken.updateMany({
                where: {
                    userId: record.userId,
                    usedAt: null,
                    expiresAt: { gt: new Date() },
                },
                data: { usedAt: new Date() },
            }),
        ]);

        return { message: 'Contraseña restablecida correctamente' };
    }

    /* ------------------------------------------------------------------
     * REFRESH TOKEN (opcional)
     * ------------------------------------------------------------------ */
    async refreshToken(userId: string) {
        const user = await this.validateUser(userId);
        if (!user) throw new UnauthorizedException('Usuario no encontrado');

        const token = await this.signToken(user.id, user.email);
        return { message: 'Token renovado exitosamente', access_token: token };
    }

    /* ------------------------------------------------------------------
     * JWT
     * ------------------------------------------------------------------ */
    private async signToken(userId: string, email: string): Promise<string> {
        const payload = { sub: userId, email };
        return this.jwt.signAsync(payload, {
            expiresIn: '7d',
            secret: process.env.JWT_SECRET || 'mi-super-secreto-jwt-2000',
        });
    }
}
