import { Body, Controller, Post, Param, UseGuards, Req, Query } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { JwtAuthGuard } from '../auth/guard/jwt-auth.guard';
import { GetUser } from '../auth/decorator/get-user.decorator';
import type { Request } from 'express';

@Controller('payments')
export class PaymentsController {
    constructor(private readonly payments: PaymentsService) { }

    /**
     * Crea una preferencia de pago para los tickets de un sorteo.
     * Requiere autenticación.
     */
    @UseGuards(JwtAuthGuard)
    @Post('raffles/:id/checkout')
    async createCheckout(
        @Param('id') raffleId: string,
        @GetUser('id') userId: string,
        @Body() body: { quantity: number },
    ) {
        const quantity = Number(body?.quantity || 0);
        return this.payments.createRaffleCheckout(userId, raffleId, quantity);
    }

    /**
     * Webhook para recibir notificaciones de Mercado Pago (IPN).
     * Esta ruta debe ser pública.
     */
    @Post('mercadopago/webhook')
    async webhook(
        @Req() req: Request, // Usamos el tipo Request de Express
        @Query() query: any,
        @Body() body: any
    ) {
        // Pasamos todos los datos relevantes al servicio para su procesamiento.
        return this.payments.handleMercadoPagoWebhook(req.headers, query, body);
    }
}