// backend/src/payments/payments.module.ts
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { PaymentsController } from './payments.controller';
import { PrismaService } from '../prisma/prisma.service';
import { RaffleService } from '../raffle/raffle.service';
import { MpWebhookSignatureMiddleware } from '../common/middleware/mp-webhook-signature.middleware';

@Module({
    controllers: [PaymentsController],
    providers: [PaymentsService, PrismaService, RaffleService],
    exports: [PaymentsService], // ✅ IMPORTANTE: Exportar para usar en OrdersModule
})
export class PaymentsModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(MpWebhookSignatureMiddleware).forRoutes('payments/mercadopago/webhook');
    }
}