import {
    Injectable,
    BadRequestException,
    Logger,
    NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RaffleService } from '../raffle/raffle.service';
import { MercadoPagoConfig, Preference, Payment } from 'mercadopago';
import { PaymentStatus, OrderStatus, TicketStatus } from '@prisma/client';

function normalizeBase(url?: string): string {
    if (!url) return '';
    return url.replace(/\/+$/, '');
}

@Injectable()
export class PaymentsService {
    private readonly logger = new Logger(PaymentsService.name);
    private readonly mpClient: MercadoPagoConfig;
    private readonly pref: Preference;
    private readonly pay: Payment;

    private readonly publicBase: string;
    private readonly apiBase: string;

    constructor(
        private prisma: PrismaService,
        private raffles: RaffleService,
    ) {
        const accessToken = process.env.MP_ACCESS_TOKEN;
        if (!accessToken) {
            this.logger.error('MP_ACCESS_TOKEN no está configurado en .env');
            throw new Error('MP_ACCESS_TOKEN no configurado');
        }

        // ✅ CORRECCIÓN: Asegurarnos de que las URLs estén correctamente formateadas
        const publicBase = process.env.PUBLIC_BASE_URL || 'http://localhost:5173';
        const apiBase = process.env.API_BASE_URL || 'http://localhost:3000/api/v1';

        this.publicBase = normalizeBase(publicBase);
        this.apiBase = normalizeBase(apiBase);

        // ✅ Validación temprana de URLs
        if (!this.publicBase || !/^https?:\/\/.+/i.test(this.publicBase)) {
            this.logger.error(`PUBLIC_BASE_URL inválida: "${this.publicBase}". Debe ser una URL completa (http://... o https://...)`);
            throw new Error('PUBLIC_BASE_URL mal configurada en .env');
        }

        if (!this.apiBase || !/^https?:\/\/.+/i.test(this.apiBase)) {
            this.logger.error(`API_BASE_URL inválida: "${this.apiBase}". Debe ser una URL completa.`);
            throw new Error('API_BASE_URL mal configurada en .env');
        }

        this.logger.log(`✅ URLs validadas -> Frontend: ${this.publicBase} | API: ${this.apiBase}`);

        this.mpClient = new MercadoPagoConfig({ accessToken });
        this.pref = new Preference(this.mpClient);
        this.pay = new Payment(this.mpClient);
    }

    async createRaffleCheckout(userId: string, raffleId: string, quantity: number) {
        const qty = Number(quantity || 0);
        if (!Number.isInteger(qty) || qty <= 0) {
            throw new BadRequestException('La cantidad (quantity) debe ser un número entero mayor a 0.');
        }

        const reservation = await this.raffles.reserveMany(raffleId, userId, qty);
        const total = reservation.pricing.total_clp;

        const raffle = await this.prisma.raffle.findUnique({
            where: { id: raffleId },
            include: { images: { where: { is_primary: true }, take: 1 } },
        });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');

        const orderNumber = `NVM-${Date.now().toString(36).toUpperCase()}`;
        const order = await this.prisma.order.create({
            data: {
                userId,
                number: orderNumber,
                status: OrderStatus.pending,
                subtotal_clp: total,
                total_clp: total,
                currency: 'CLP',
                discount_clp: 0,
                tax_clp: 0,
                shipping_clp: 0,
            },
        });

        if (reservation.numbers?.length) {
            await this.prisma.raffleTicket.updateMany({
                where: { raffleId, userId, status: TicketStatus.reserved, number: { in: reservation.numbers } },
                data: { orderId: order.id },
            });
        }

        const payment = await this.prisma.payment.create({
            data: { orderId: order.id, provider: 'mercadopago', status: PaymentStatus.init, amount_clp: total },
        });

        const notificationUrl = `${this.apiBase}/payments/mercadopago/webhook`;
        const itemTitle = `Tickets Sorteo: ${raffle.name}`;
        const pictureUrl = raffle.images?.[0]?.s3_key;

        try {
            // ✅ CORRECCIÓN: Construir las URLs de retorno ANTES de crear el body
            const successUrl = `${this.publicBase}/checkout-success?order_id=${order.id}`;
            const failureUrl = `${this.publicBase}/checkout-failure?order_id=${order.id}`;
            const pendingUrl = `${this.publicBase}/checkout-pending?order_id=${order.id}`;

            this.logger.log(`📍 URLs de retorno generadas:`);
            this.logger.log(`   Success: ${successUrl}`);
            this.logger.log(`   Failure: ${failureUrl}`);
            this.logger.log(`   Pending: ${pendingUrl}`);

            const useBackUrls = String(process.env.MP_USE_BACK_URLS).toLowerCase() === 'true';

            // ✅ CORRECCIÓN: Construir el objeto body según si usamos back_urls o no
            let body: any;

            if (useBackUrls) {
                body = {
                    items: [{
                        id: raffle.id,
                        title: itemTitle,
                        quantity: 1,
                        unit_price: total,
                        currency_id: 'CLP',
                        picture_url: pictureUrl,
                    }],
                    back_urls: {
                        success: successUrl,
                        failure: failureUrl,
                        pending: pendingUrl,
                    },
                    auto_return: 'approved',
                    external_reference: payment.id,
                    notification_url: notificationUrl,
                    statement_descriptor: 'NIVEM RIFAS',
                };
                this.logger.log(`✅ back_urls activadas para MP`);
            } else {
                body = {
                    items: [{
                        id: raffle.id,
                        title: itemTitle,
                        quantity: 1,
                        unit_price: total,
                        currency_id: 'CLP',
                        picture_url: pictureUrl,
                    }],
                    external_reference: payment.id,
                    notification_url: notificationUrl,
                    statement_descriptor: 'NIVEM RIFAS',
                };
                this.logger.log(`⚠️ MP_USE_BACK_URLS desactivado, no se envían back_urls`);
            }

            this.logger.log(`📤 Enviando preferencia a MP:`, JSON.stringify(body, null, 2));

            const preference = await this.pref.create({ body });
            const preferenceId = preference?.id;
            const initPoint = preference?.init_point || (preference as any)?.sandbox_init_point;

            if (!preferenceId || !initPoint) {
                this.logger.error(`❌ Respuesta inválida de MP: ${JSON.stringify(preference)}`);
                throw new BadRequestException('No se pudo crear la preferencia de pago con Mercado Pago.');
            }

            await this.prisma.payment.update({
                where: { id: payment.id },
                data: { mp_preference_id: preferenceId },
            });

            this.logger.log(`✅ Preferencia creada: ${preferenceId}`);

            return {
                message: 'Preferencia creada exitosamente.',
                preference_id: preferenceId,
                init_point: initPoint,
                order_id: order.id,
                reservation
            };

        } catch (err: any) {
            const mpError = err?.cause || err;
            this.logger.error(`❌ Error al crear preferencia en MP: ${err.message}`);
            this.logger.error(`Detalles del error:`, JSON.stringify(mpError, null, 2));
            throw new BadRequestException('Error al comunicarse con el procesador de pagos.');
        }
    }

    async handleMercadoPagoWebhook(headers: any, query: any, body: any) {
        const topic = query?.type || body?.type;
        const mpPaymentId = query?.data?.id || body?.data?.id;

        if (topic !== 'payment' || !mpPaymentId) {
            this.logger.log(`Webhook ignorado (tópico o ID no válido): topic=${topic}, id=${mpPaymentId}`);
            return { ok: true };
        }

        try {
            const mpPayment = await this.pay.get({ id: mpPaymentId });
            const status = mpPayment?.status;
            const externalRef = mpPayment?.external_reference;

            if (!externalRef || !status) {
                this.logger.warn(`Webhook sin external_reference o status. MP Payment ID: ${mpPaymentId}`);
                return { ok: true };
            }

            const payment = await this.prisma.payment.findUnique({ where: { id: externalRef } });
            if (!payment) {
                this.logger.warn(`Payment con external_reference ${externalRef} no encontrado en la BD.`);
                return { ok: true };
            }

            if (payment.status === PaymentStatus.approved) return { ok: true };

            if (status === 'approved') {
                await this.prisma.$transaction(async (tx) => {
                    await tx.payment.update({
                        where: { id: payment.id },
                        data: { status: PaymentStatus.approved, mp_payment_id: String(mpPaymentId) },
                    });

                    const orderId = payment.orderId;
                    if (!orderId) return;

                    const tickets = await tx.raffleTicket.findMany({
                        where: { orderId, status: TicketStatus.reserved },
                        select: { id: true, raffleId: true },
                    });
                    if (tickets.length === 0) return;

                    const raffleId = tickets[0].raffleId;
                    const qty = tickets.length;

                    await tx.raffleTicket.updateMany({
                        where: { orderId, status: TicketStatus.reserved },
                        data: { status: TicketStatus.paid, reservation_expires_at: null },
                    });

                    await tx.raffle.update({
                        where: { id: raffleId },
                        data: { reserved_tickets: { decrement: qty }, paid_tickets: { increment: qty } },
                    });

                    await tx.order.update({ where: { id: orderId }, data: { status: OrderStatus.paid } });
                });

                this.logger.log(`✅ Pago ${payment.id} aprobado y procesado correctamente.`);
            } else {
                const newStatus = ['rejected', 'cancelled', 'failed'].includes(status)
                    ? PaymentStatus.rejected
                    : PaymentStatus.init;

                await this.prisma.payment.update({
                    where: { id: payment.id },
                    data: { status: newStatus, mp_payment_id: String(mpPaymentId) },
                });
                this.logger.log(`Pago ${payment.id} actualizado a estado: ${newStatus}`);
            }

            return { ok: true };

        } catch (error) {
            this.logger.error(`Error procesando webhook de MP para el pago ${mpPaymentId}:`, error);
            throw new Error('Error al procesar el webhook.');
        }
    }
    // AGREGAR AL FINAL DE payments.service.ts (después del método handleMercadoPagoWebhook)

    async createOrderPreference(orderId: string) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: {
                user: true,
                items: {
                    include: {
                        product: {
                            include: {
                                images: true,
                            },
                        },
                        variant: true,
                    },
                },
            },
        });

        if (!order) {
            throw new NotFoundException('Orden no encontrada');
        }

        if (order.status !== OrderStatus.draft && order.status !== OrderStatus.pending) {
            throw new BadRequestException('Esta orden no puede ser pagada');
        }

        const payment = await this.prisma.payment.create({
            data: {
                orderId: order.id,
                provider: 'mercadopago',
                status: PaymentStatus.init,
                amount_clp: order.total_clp,
            },
        });

        const items = order.items.map((item) => {
            const primaryImage = item.product.images.find(img => img.is_primary) || item.product.images[0];

            return {
                id: item.variantId || item.productId,
                title: item.title_snap,
                description: item.sku_snap ? `SKU: ${item.sku_snap}` : '',
                quantity: item.qty,
                unit_price: item.unit_price_clp,
                currency_id: 'CLP',
                picture_url: primaryImage?.s3_key,
            };
        });

        const notificationUrl = `${this.apiBase}/payments/mercadopago/webhook`;
        const useBackUrls = String(process.env.MP_USE_BACK_URLS).toLowerCase() === 'true';

        const successUrl = `${this.publicBase}/checkout/success?order_id=${order.id}`;
        const failureUrl = `${this.publicBase}/checkout/failure?order_id=${order.id}`;
        const pendingUrl = `${this.publicBase}/checkout/pending?order_id=${order.id}`;

        this.logger.log(`📍 URLs de retorno para orden ${order.number}:`);
        this.logger.log(`   Success: ${successUrl}`);
        this.logger.log(`   Failure: ${failureUrl}`);
        this.logger.log(`   Pending: ${pendingUrl}`);

        let body: any;

        if (useBackUrls) {
            body = {
                items,
                payer: {
                    email: order.user.email,
                    name: order.user.name || undefined,
                    surname: order.user.lastname || undefined,
                    phone: order.user.phone ? { number: order.user.phone } : undefined,
                },
                back_urls: {
                    success: successUrl,
                    failure: failureUrl,
                    pending: pendingUrl,
                },
                auto_return: 'approved',
                external_reference: payment.id,
                notification_url: notificationUrl,
                statement_descriptor: 'NIVEM STORE',
                metadata: {
                    order_id: order.id,
                    order_number: order.number,
                    payment_id: payment.id,
                },
            };
            this.logger.log(`✅ back_urls activadas para MP`);
        } else {
            body = {
                items,
                payer: {
                    email: order.user.email,
                    name: order.user.name || undefined,
                    surname: order.user.lastname || undefined,
                    phone: order.user.phone ? { number: order.user.phone } : undefined,
                },
                external_reference: payment.id,
                notification_url: notificationUrl,
                statement_descriptor: 'NIVEM STORE',
                metadata: {
                    order_id: order.id,
                    order_number: order.number,
                    payment_id: payment.id,
                },
            };
            this.logger.log(`⚠️ MP_USE_BACK_URLS desactivado, no se envían back_urls`);
        }

        try {
            this.logger.log(`📤 Creando preferencia para orden ${order.number}`);

            const preference = await this.pref.create({ body });
            const preferenceId = preference?.id;
            const initPoint = preference?.init_point || (preference as any)?.sandbox_init_point;

            if (!preferenceId || !initPoint) {
                this.logger.error(`❌ Respuesta inválida de MP: ${JSON.stringify(preference)}`);
                throw new BadRequestException('No se pudo crear la preferencia de pago con Mercado Pago.');
            }

            await this.prisma.payment.update({
                where: { id: payment.id },
                data: { mp_preference_id: preferenceId },
            });

            await this.prisma.order.update({
                where: { id: order.id },
                data: { status: OrderStatus.pending },
            });

            this.logger.log(`✅ Preferencia creada: ${preferenceId}`);

            return {
                message: 'Preferencia creada exitosamente.',
                preference_id: preferenceId,
                init_point: initPoint,
                order_id: order.id,
            };

        } catch (err: any) {
            const mpError = err?.cause || err;
            this.logger.error(`❌ Error al crear preferencia en MP: ${err.message}`);
            this.logger.error(`Detalles del error:`, JSON.stringify(mpError, null, 2));
            throw new BadRequestException('Error al comunicarse con el procesador de pagos.');
        }
    }


}