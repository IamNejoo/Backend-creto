// backend/src/dashboard/dashboard.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DashboardService {
    constructor(private prisma: PrismaService) { }

    async getStats() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);

        const [salesToday, salesWeek, ordersNew, usersTotal, recentOrders, topProducts, raffle] = await Promise.all([
            this.prisma.order.aggregate({
                where: { status: 'paid', createdAt: { gte: today } },
                _sum: { total_clp: true },
            }),
            this.prisma.order.aggregate({
                where: { status: 'paid', createdAt: { gte: weekAgo } },
                _sum: { total_clp: true },
            }),
            this.prisma.order.count({
                where: { status: { in: ['pending', 'draft'] } },
            }),
            this.prisma.user.count(),
            this.prisma.order.findMany({
                take: 5,
                orderBy: { createdAt: 'desc' },
                select: {
                    id: true,
                    number: true,
                    status: true,
                    total_clp: true,
                    createdAt: true,
                },
            }),
            this.getTopProducts(),
            this.getRaffleStatus(),
        ]);

        return {
            stats: {
                sales_today: salesToday._sum.total_clp || 0,
                sales_week: salesWeek._sum.total_clp || 0,
                orders_new: ordersNew,
                users_total: usersTotal,
            },
            recent_orders: recentOrders,
            top_products: topProducts,
            raffle,
        };
    }

    private async getTopProducts() {
        const sales = await this.prisma.orderItem.groupBy({
            by: ['productId'],
            where: {
                order: { status: 'paid' },
            },
            _sum: {
                qty: true,
                total_clp: true,
            },
            orderBy: {
                _sum: {
                    qty: 'desc',
                },
            },
            take: 5,
        });

        const products = await this.prisma.product.findMany({
            where: { id: { in: sales.map(s => s.productId) } },
            select: { id: true, title: true },
        });

        return sales.map(s => ({
            productId: s.productId,
            title: products.find(p => p.id === s.productId)?.title || 'Producto',
            sales: s._sum.qty || 0,
            revenue: s._sum.total_clp || 0,
        }));
    }

    private async getRaffleStatus() {
        const now = new Date();
        const raffle = await this.prisma.raffle.findFirst({
            where: {
                starts_at: { lte: now },
                ends_at: { gte: now },
            },
            orderBy: { ends_at: 'asc' },
        });

        return raffle || null;
    }
}