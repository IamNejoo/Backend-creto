// src/main.ts
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import helmet from 'helmet';
import { Logger } from '@nestjs/common'; // 👈 agrega esto

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap'); // 👈 para logs iniciales

  // 🛡️ SEGURIDAD HEADERS
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
    },
  }));

  // 🔒 CORS SEGURO
  const corsOrigins = process.env.CORS_ORIGINS?.split(',') || ['http://localhost:5173', 'http://127.0.0.1:5173'];

  app.enableCors({
    origin: corsOrigins, // 👈 AHORA ES DINÁMICO
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-CSRF-Token',
      'X-Client-Fingerprint',
    ],
  });

  logger.log(`Orígenes CORS permitidos: ${corsOrigins.join(', ')}`);

  // ✅ VALIDACIÓN GLOBAL
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
    transformOptions: { enableImplicitConversion: true },
  }));

  // 📝 PREFIX API
  app.setGlobalPrefix('api/v1');

  // 🕒 SCHEDULE MODULE (cron jobs)
  // ✅ NO se importa aquí manualmente, pero asegúrate de que AppModule lo tenga
  // importado junto con RaffleModule → eso activa los jobs automáticos.

  const port = process.env.PORT || 3000;
  await app.listen(port);

  logger.log(`🚀 Servidor iniciado en http://localhost:${port}/api/v1`);
}
bootstrap();
