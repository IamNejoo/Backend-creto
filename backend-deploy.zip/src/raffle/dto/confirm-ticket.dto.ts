import { IsNotEmpty, IsString, IsInt, Min } from 'class-validator';

export class ConfirmTicketDto {
    @IsNotEmpty()
    @IsString()
    raffleId: string;

    @IsNotEmpty()
    @IsInt()
    @Min(1)
    ticketNumber: number;
}
