import { IsNotEmpty, IsString } from 'class-validator';

export class ReserveTicketDto {
    @IsNotEmpty()
    @IsString()
    raffleId: string;
}
