import { IsInt, IsNotEmpty, IsString, Min } from 'class-validator';

export class ReserveManyDto {
    @IsNotEmpty() @IsString()
    raffleId: string;

    @IsInt() @Min(1)
    quantity: number;
}
