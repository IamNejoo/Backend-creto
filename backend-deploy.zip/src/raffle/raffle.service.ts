// src/raffle/raffle.service.ts
import {
    Injectable,
    BadRequestException,
    ConflictException,
    NotFoundException,
    Logger,
    ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Prisma, TicketStatus } from '../../generated/prisma';
import { S3Client } from '@aws-sdk/client-s3';
import { createPresignedPost } from '@aws-sdk/s3-presigned-post';
import * as path from 'path';
import { randomUUID } from 'crypto';
@Injectable()
export class RaffleService {
    private readonly logger = new Logger(RaffleService.name);
    private readonly s3 = new S3Client({
        region: process.env.AWS_REGION,
        credentials: process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY
            ? {
                accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
            }
            : undefined,
    });

    private readonly bucket = process.env.S3_BUCKET!;
    private readonly publicBaseS3 = (process.env.PUBLIC_BASE_S3 || '').replace(/\/+$/, '');
    constructor(private prisma: PrismaService) { }

    /* ======= CRUD básico ======= */

    async createRaffle(dto: {
        name: string;
        ticket_price_clp: number;
        total_tickets: number;
        starts_at: string;
        ends_at: string;
    }) {
        if (dto.total_tickets <= 0) {
            throw new BadRequestException('total_tickets debe ser > 0');
        }
        const starts = new Date(dto.starts_at);
        const ends = new Date(dto.ends_at);
        if (Number.isNaN(+starts) || Number.isNaN(+ends)) {
            throw new BadRequestException('Fechas inválidas');
        }
        if (ends <= starts) {
            throw new BadRequestException('ends_at debe ser posterior a starts_at');
        }

        const raffle = await this.prisma.raffle.create({
            data: {
                name: dto.name,
                ticket_price_clp: dto.ticket_price_clp,
                total_tickets: dto.total_tickets,
                starts_at: starts,
                ends_at: ends,
            },
        });

        return { message: 'Sorteo creado', raffle };
    }

    async updateRaffle(
        id: string,
        dto: Partial<{
            name: string;
            ticket_price_clp: number;
            total_tickets: number;
            starts_at: string;
            ends_at: string;
            // si más adelante expones flags como is_featured/mode/etc., agrégalos aquí
        }>,
    ) {
        const raffle = await this.prisma.raffle.findUnique({ where: { id } });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');

        if (dto.starts_at && dto.ends_at) {
            const s = new Date(dto.starts_at);
            const e = new Date(dto.ends_at);
            if (Number.isNaN(+s) || Number.isNaN(+e)) throw new BadRequestException('Fechas inválidas');
            if (e <= s) throw new BadRequestException('ends_at debe ser posterior a starts_at');
        }

        const updated = await this.prisma.raffle.update({
            where: { id },
            data: {
                name: dto.name ?? undefined,
                ticket_price_clp: dto.ticket_price_clp ?? undefined,
                total_tickets: dto.total_tickets ?? undefined,
                starts_at: dto.starts_at ? new Date(dto.starts_at) : undefined,
                ends_at: dto.ends_at ? new Date(dto.ends_at) : undefined,
            },
        });

        return { message: 'Sorteo actualizado', raffle: updated };
    }

    async deleteRaffle(id: string) {
        const r = await this.prisma.raffle.findUnique({
            where: { id },
            select: { id: true, paid_tickets: true },
        });
        if (!r) throw new NotFoundException('Sorteo no encontrado');
        if (r.paid_tickets > 0) throw new BadRequestException('No puedes eliminar un sorteo con tickets pagados');

        await this.prisma.$transaction(async (tx) => {
            await tx.raffleImage.deleteMany({ where: { raffleId: id } });
            await tx.rafflePricingTier.deleteMany({ where: { raffleId: id } });
            await tx.raffleTicket.deleteMany({ where: { raffleId: id } });
            await tx.raffle.delete({ where: { id } });
        });

        return { message: 'Sorteo eliminado' };
    }

    async listRaffles(
        includeImages = false,
        includeTiers = false,
        status?: 'active' | 'scheduled' | 'finished',
    ) {
        const now = new Date();
        const where: Prisma.RaffleWhereInput = {};

        if (status === 'active') {
            where.starts_at = { lte: now };
            where.ends_at = { gte: now };
        } else if (status === 'scheduled') {
            where.starts_at = { gt: now };
        } else if (status === 'finished') {
            where.ends_at = { lt: now };
        }

        const raffles = await this.prisma.raffle.findMany({
            where,
            include: {
                images: includeImages ? { orderBy: [{ is_primary: 'desc' }, { position: 'asc' }] } : false,
                pricingTiers: includeTiers
                    ? {
                        where: {
                            active: true,
                            OR: [
                                { starts_at: null, ends_at: null },
                                { starts_at: { lte: now }, ends_at: { gte: now } },
                                { starts_at: { lte: now }, ends_at: null },
                                { starts_at: null, ends_at: { gte: now } },
                            ],
                        },
                        orderBy: [{ sort: 'asc' }, { quantity: 'asc' }],
                    }
                    : false,
            },
            orderBy: [{ createdAt: 'desc' }],
        });
        return { raffles };
    }

    async getFeatured() {
        const now = new Date();
        let raffle = await this.prisma.raffle.findFirst({
            where: { starts_at: { lte: now }, ends_at: { gte: now }, is_featured: true },
            include: {
                images: { orderBy: [{ is_primary: 'desc' }, { position: 'asc' }] },
                pricingTiers: {
                    where: {
                        active: true,
                        OR: [
                            { starts_at: null, ends_at: null },
                            { starts_at: { lte: now }, ends_at: { gte: now } },
                            { starts_at: { lte: now }, ends_at: null },
                            { starts_at: null, ends_at: { gte: now } },
                        ],
                    },
                    orderBy: [{ sort: 'asc' }, { quantity: 'asc' }],
                },
            },
        });

        if (!raffle) {
            raffle = await this.prisma.raffle.findFirst({
                where: { starts_at: { lte: now }, ends_at: { gte: now } },
                orderBy: { ends_at: 'asc' },
                include: {
                    images: { orderBy: [{ is_primary: 'desc' }, { position: 'asc' }] },
                    pricingTiers: {
                        where: { active: true },
                        orderBy: [{ sort: 'asc' }, { quantity: 'asc' }],
                    },
                },
            });
        }
        return { raffle };
    }

    async getRaffle(id: string) {
        const now = new Date();
        const raffle = await this.prisma.raffle.findUnique({
            where: { id },
            include: {
                images: { orderBy: [{ is_primary: 'desc' }, { position: 'asc' }] },
                pricingTiers: {
                    where: {
                        active: true,
                        OR: [
                            { starts_at: null, ends_at: null },
                            { starts_at: { lte: now }, ends_at: { gte: now } },
                            { starts_at: { lte: now }, ends_at: null },
                            { starts_at: null, ends_at: { gte: now } },
                        ],
                    },
                    orderBy: [{ sort: 'asc' }, { quantity: 'asc' }],
                },
            },
        });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');
        return { raffle };
    }

    /* ======= Tiers ======= */

    async listTiers(raffleId: string) {
        const raffle = await this.prisma.raffle.findUnique({ where: { id: raffleId } });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');

        const tiers = await this.prisma.rafflePricingTier.findMany({
            where: { raffleId },
            orderBy: [{ sort: 'asc' }, { quantity: 'asc' }],
        });
        return { tiers };
    }

    async createTier(raffleId: string, dto: {
        quantity: number;
        price_clp: number;
        active?: boolean;
        sort?: number;
        starts_at?: string;
        ends_at?: string;
        label?: string | null;
    }) {
        if (dto.quantity <= 0) throw new BadRequestException('quantity debe ser > 0');
        if (dto.price_clp < 0) throw new BadRequestException('price_clp no puede ser negativo');

        const tier = await this.prisma.rafflePricingTier.create({
            data: {
                raffleId,
                quantity: dto.quantity,
                price_clp: dto.price_clp,
                active: dto.active ?? true,
                sort: dto.sort ?? 0,
                starts_at: dto.starts_at ? new Date(dto.starts_at) : null,
                ends_at: dto.ends_at ? new Date(dto.ends_at) : null,
                label: dto.label ?? null,
            },
        });
        return { message: 'Tier creado', tier };
    }

    async updateTier(
        raffleId: string,
        tierId: string,
        dto: Partial<{
            quantity: number;
            price_clp: number;
            active: boolean;
            sort: number;
            starts_at: string;
            ends_at: string;
            label: string | null;
        }>,
    ) {
        const t = await this.prisma.rafflePricingTier.findUnique({ where: { id: tierId } });
        if (!t || t.raffleId !== raffleId) throw new NotFoundException('Tier no encontrado');

        const updated = await this.prisma.rafflePricingTier.update({
            where: { id: tierId },
            data: {
                quantity: dto.quantity ?? undefined,
                price_clp: dto.price_clp ?? undefined,
                active: dto.active ?? undefined,
                sort: dto.sort ?? undefined,
                starts_at: dto.starts_at ? new Date(dto.starts_at) : undefined,
                ends_at: dto.ends_at ? new Date(dto.ends_at) : undefined,
                label: dto.label ?? undefined,
            },
        });
        return { message: 'Tier actualizado', tier: updated };
    }

    async deleteTier(raffleId: string, tierId: string) {
        const t = await this.prisma.rafflePricingTier.findUnique({ where: { id: tierId } });
        if (!t || t.raffleId !== raffleId) throw new NotFoundException('Tier no encontrado');

        await this.prisma.rafflePricingTier.delete({ where: { id: tierId } });
        return { message: 'Tier eliminado' };
    }

    /* ======= Imágenes ======= */

    async addImage(raffleId: string, publicUrl: string) {
        const raffle = await this.prisma.raffle.findUnique({ where: { id: raffleId } });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');

        const count = await this.prisma.raffleImage.count({ where: { raffleId } });
        const image = await this.prisma.raffleImage.create({
            data: {
                raffleId,
                s3_key: publicUrl,
                is_primary: count === 0,
                position: count,
            },
        });

        return { message: 'Imagen añadida', image };
    }

    async setPrimaryImage(raffleId: string, imageId: string) {
        const img = await this.prisma.raffleImage.findUnique({ where: { id: imageId } });
        if (!img || img.raffleId !== raffleId) throw new NotFoundException('Imagen no encontrada');

        await this.prisma.$transaction(async (tx) => {
            await tx.raffleImage.updateMany({ where: { raffleId }, data: { is_primary: false } });
            await tx.raffleImage.update({ where: { id: imageId }, data: { is_primary: true } });
        });

        const images = await this.prisma.raffleImage.findMany({
            where: { raffleId },
            orderBy: [{ is_primary: 'desc' }, { position: 'asc' }],
        });

        return { message: 'Imagen marcada como principal', images };
    }

    async deleteImage(raffleId: string, imageId: string) {
        const img = await this.prisma.raffleImage.findUnique({ where: { id: imageId } });
        if (!img || img.raffleId !== raffleId) throw new NotFoundException('Imagen no encontrada');

        await this.prisma.raffleImage.delete({ where: { id: imageId } });

        const primaryExists = await this.prisma.raffleImage.findFirst({
            where: { raffleId, is_primary: true },
        });
        if (!primaryExists) {
            const first = await this.prisma.raffleImage.findFirst({
                where: { raffleId },
                orderBy: { position: 'asc' },
            });
            if (first) {
                await this.prisma.raffleImage.update({
                    where: { id: first.id },
                    data: { is_primary: true },
                });
            }
        }

        const images = await this.prisma.raffleImage.findMany({
            where: { raffleId },
            orderBy: [{ is_primary: 'desc' }, { position: 'asc' }],
        });

        return { message: 'Imagen eliminada', images };
    }
    // NUEVO: registra imagen subida a S3 (key o URL)
    async addImageFromS3(raffleId: string, keyOrUrl: string) {
        let publicUrl = keyOrUrl;
        if (!/^https?:\/\//i.test(keyOrUrl)) {
            if (!this.publicBaseS3) {
                throw new BadRequestException('PUBLIC_BASE_S3 no está configurado');
            }
            publicUrl = `${this.publicBaseS3}/${keyOrUrl.replace(/^\/+/, '')}`;
        }
        return this.addImage(raffleId, publicUrl);
    }

    // NUEVO: presigned POST para limitar tamaño y MIME
    async createRaffleImagePresign(raffleId: string, filename: string, contentType: string) {
        const raffle = await this.prisma.raffle.findUnique({ where: { id: raffleId } });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');

        const okMime = /^image\/(png|jpe?g|webp)$/i.test(contentType);
        if (!okMime) throw new BadRequestException('Tipo MIME no permitido');

        const ext = path.extname(filename || '').toLowerCase() || this.guessExt(contentType);
        const uuid = randomUUID();
        const key = `raffles/${raffleId}/${uuid}${ext}`;

        const MAX_BYTES = 6 * 1024 * 1024; // 6 MB

        const presign = await createPresignedPost(this.s3, {
            Bucket: this.bucket,
            Key: key,
            Conditions: [
                ['content-length-range', 1, MAX_BYTES],
                ['starts-with', '$Content-Type', 'image/'],
            ],
            Fields: {
                'Content-Type': contentType,
            },
            Expires: 600, // 10 min
        });

        const publicUrl = this.publicBaseS3
            ? `${this.publicBaseS3}/${key}`
            : `https://${this.bucket}.s3.${process.env.AWS_REGION}.amazonaws.com/${key}`;

        return {
            message: 'URL prefirmada creada',
            key,
            upload: presign,
            public_url: publicUrl,
            max_bytes: MAX_BYTES,
            allowed_mime: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'],
        };
    }

    private guessExt(ct: string) {
        if (/png$/i.test(ct)) return '.png';
        if (/jpe?g$/i.test(ct)) return '.jpg';
        if (/webp$/i.test(ct)) return '.webp';
        return '.img';
    }
    /* ======= Tickets ======= */

    private ensureActive(raffle: { starts_at: Date; ends_at: Date }) {
        const now = new Date();
        if (now < raffle.starts_at || now > raffle.ends_at) {
            throw new ForbiddenException('El sorteo no está activo');
        }
    }

    // Reserva 1 (compatibilidad)
    async reserveTicket(raffleId: string, userId: string) {
        return this.reserveMany(raffleId, userId, 1);
    }

    // Reserva N con transacción SERIALIZABLE + cálculo de precio por tiers
    // Reemplaza el método reserveMany completo en raffle.service.ts

    async reserveMany(raffleId: string, userId: string, quantity: number) {
        if (quantity <= 0) throw new BadRequestException('quantity debe ser > 0');

        const raffle = await this.prisma.raffle.findUnique({
            where: { id: raffleId },
            include: { pricingTiers: true },
        });
        if (!raffle) throw new NotFoundException('Sorteo no encontrado');
        this.ensureActive(raffle);

        const remaining = raffle.total_tickets - (raffle.reserved_tickets + raffle.paid_tickets);
        if (remaining < quantity) {
            throw new BadRequestException(`Solo quedan ${remaining} tickets disponibles`);
        }

        // Prepara cálculo de precio
        const pricing = this.computeBestPricing(raffle.ticket_price_clp, quantity, raffle.pricingTiers);

        // ✅ CORRECCIÓN: Transacción SERIALIZABLE con limpieza de expirados
        const numbers = await this.prisma.$transaction(
            async (tx) => {
                const now = new Date();

                // 🔥 PASO 1: ELIMINAR TODOS los tickets expirados (incluye expired status)
                const expiredTickets = await tx.raffleTicket.findMany({
                    where: {
                        raffleId,
                        OR: [
                            {
                                status: TicketStatus.reserved,
                                reservation_expires_at: { lte: now }
                            },
                            {
                                status: TicketStatus.expired
                            }
                        ]
                    },
                    select: { id: true, status: true }
                });

                if (expiredTickets.length > 0) {
                    this.logger.log(`🧹 Limpiando ${expiredTickets.length} tickets expirados para sorteo ${raffleId}`);

                    // Eliminar todos los tickets expirados
                    await tx.raffleTicket.deleteMany({
                        where: {
                            raffleId,
                            OR: [
                                {
                                    status: TicketStatus.reserved,
                                    reservation_expires_at: { lte: now }
                                },
                                {
                                    status: TicketStatus.expired
                                }
                            ]
                        }
                    });

                    // Contar cuántos eran 'reserved' para ajustar el contador
                    const reservedCount = expiredTickets.filter(t => t.status === TicketStatus.reserved).length;
                    if (reservedCount > 0) {
                        await tx.raffle.update({
                            where: { id: raffleId },
                            data: { reserved_tickets: { decrement: reservedCount } }
                        });
                    }
                }

                // 🔥 PASO 2: Obtener TODOS los números ocupados (cualquier ticket que exista)
                const allTickets = await tx.raffleTicket.findMany({
                    where: { raffleId },
                    select: { number: true, status: true }
                });

                const occupiedNumbers = new Set(allTickets.map(t => t.number));
                this.logger.log(`📊 Sorteo ${raffleId}: ${occupiedNumbers.size} números ocupados de ${raffle.total_tickets} (estados: ${JSON.stringify([...new Set(allTickets.map(t => t.status))])})`);

                // 🔥 PASO 3: Verificar disponibilidad real
                const actuallyAvailable = raffle.total_tickets - occupiedNumbers.size;
                if (actuallyAvailable < quantity) {
                    throw new BadRequestException(
                        `No hay suficientes tickets disponibles. Solicitados: ${quantity}, Disponibles: ${actuallyAvailable}`
                    );
                }

                // 🔥 PASO 4: Generar lista de números disponibles
                const availableNumbers: number[] = [];
                for (let i = 1; i <= raffle.total_tickets; i++) {
                    if (!occupiedNumbers.has(i)) {
                        availableNumbers.push(i);
                    }
                }

                // 🔥 PASO 5: Seleccionar números SECUENCIALES de los disponibles
                const selectedNumbers = availableNumbers.slice(0, quantity);

                this.logger.log(`🎯 Seleccionados ${selectedNumbers.length} números secuenciales para usuario ${userId}: ${selectedNumbers.join(', ')}`);

                // 🔥 PASO 6: Crear tickets con números garantizados como disponibles
                const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutos
                const createdTickets = await Promise.all(
                    selectedNumbers.map(number =>
                        tx.raffleTicket.create({
                            data: {
                                raffleId,
                                userId,
                                number,
                                status: TicketStatus.reserved,
                                reservation_expires_at: expiresAt,
                            },
                        })
                    )
                );

                // 🔥 PASO 7: Actualizar contador de reservados
                await tx.raffle.update({
                    where: { id: raffleId },
                    data: { reserved_tickets: { increment: selectedNumbers.length } },
                });

                this.logger.log(`✅ Reserva exitosa: ${selectedNumbers.length} tickets secuenciales para orden`);

                return selectedNumbers;
            },
            { isolationLevel: 'Serializable' as any },
        );

        return {
            message: 'Tickets reservados',
            numbers: numbers.sort((a, b) => a - b),
            pricing,
            expires_in_seconds: 5 * 60,
        };
    }
    async confirmTicket(raffleId: string, userId: string, ticketNumber: number) {
        const ticket = await this.prisma.raffleTicket.findUnique({
            where: { raffleId_number: { raffleId, number: ticketNumber } },
        });

        if (!ticket) throw new NotFoundException('Ticket no encontrado');
        if (ticket.status !== TicketStatus.reserved) {
            throw new BadRequestException('El ticket no está reservado');
        }
        if (ticket.userId !== userId) {
            throw new BadRequestException('El ticket no pertenece a este usuario');
        }

        await this.prisma.$transaction(async (tx) => {
            await tx.raffleTicket.update({
                where: { id: ticket.id },
                data: { status: TicketStatus.paid, reservation_expires_at: null },
            });
            await tx.raffle.update({
                where: { id: raffleId },
                data: {
                    reserved_tickets: { decrement: 1 },
                    paid_tickets: { increment: 1 },
                },
            });
        });

        return { message: 'Ticket confirmado' };
    }

    // Cron: expira reservas y ajusta contadores por sorteo
    @Cron(CronExpression.EVERY_MINUTE)
    async expireReservations() {
        const now = new Date();

        // Agrupa por sorteo las reservas vencidas (antes de mutar)
        const toExpire = await this.prisma.raffleTicket.groupBy({
            by: ['raffleId'],
            where: { status: TicketStatus.reserved, reservation_expires_at: { lt: now } },
            _count: { _all: true },
        });

        if (toExpire.length === 0) return;

        await this.prisma.$transaction(async (tx) => {
            // marca todos como expirados
            await tx.raffleTicket.updateMany({
                where: { status: TicketStatus.reserved, reservation_expires_at: { lt: now } },
                data: { status: TicketStatus.expired },
            });

            // decrementa reserved_tickets por sorteo
            for (const g of toExpire) {
                await tx.raffle.update({
                    where: { id: g.raffleId },
                    data: { reserved_tickets: { decrement: g._count._all } },
                });
            }
        });

        const total = toExpire.reduce((s, g) => s + g._count._all, 0);
        this.logger.log(`Expiraron ${total} reservas en ${toExpire.length} sorteos`);
    }

    async listTickets(raffleId: string) {
        const tickets = await this.prisma.raffleTicket.findMany({
            where: { raffleId },
            select: {
                id: true,
                number: true,
                status: true,
                user: { select: { name: true, lastname: true, email: true } },
                orderId: true,
            },
            orderBy: { number: 'asc' },
        });
        return { tickets };
    }

    /* ======= Pricing helper ======= */

    private computeBestPricing(
        baseUnitPrice: number,
        quantity: number,
        tiers: { quantity: number; price_clp: number; active?: boolean }[],
    ) {
        const candidates = (tiers || []).filter((t) => (t?.active ?? true) && t.quantity > 0);
        const sorted = candidates.sort((a, b) => a.price_clp / a.quantity - b.price_clp / b.quantity);

        let remaining = quantity;
        const breakdown: { kind: 'tier' | 'base'; quantity: number; unit_price_clp: number; total_clp: number }[] = [];
        let total = 0;

        for (const t of sorted) {
            if (remaining >= t.quantity) {
                const packs = Math.floor(remaining / t.quantity);
                if (packs > 0) {
                    const packQty = packs * t.quantity;
                    const unit = Math.floor(t.price_clp / t.quantity);
                    const part = packs * t.price_clp;
                    breakdown.push({ kind: 'tier', quantity: packQty, unit_price_clp: unit, total_clp: part });
                    total += part;
                    remaining -= packQty;
                }
            }
        }

        if (remaining > 0) {
            const part = remaining * baseUnitPrice;
            breakdown.push({ kind: 'base', quantity: remaining, unit_price_clp: baseUnitPrice, total_clp: part });
            total += part;
            remaining = 0;
        }

        return { total_clp: total, breakdown };
    }
}
